# CCS811 library
This is a very basic Arduino library for the CCS811 digital TVOC/eCO2 Sensor by CCMOSS/AMS. It is under development and may have potential bugs in code.

Breakout board available [here] (https://github.com/AKstudios/CCS811-Breakout).
